enum ChatMode{
  PRIVATE,GENERAL;
}