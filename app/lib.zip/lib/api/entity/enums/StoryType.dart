enum StoryType{
  PHOTO,VIDEO;
}