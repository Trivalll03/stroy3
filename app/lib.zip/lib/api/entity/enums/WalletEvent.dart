enum WalletEvent{
  PAYMENT,ADD,SUBTRACT,ADJUST;
}