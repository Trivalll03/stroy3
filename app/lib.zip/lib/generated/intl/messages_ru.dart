// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ru locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ru';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "accept": MessageLookupByLibrary.simpleMessage(
            "Принимаю политику конфиденциальности"),
        "add": MessageLookupByLibrary.simpleMessage("Добавить"),
        "add_money": MessageLookupByLibrary.simpleMessage("Пополнить счёт"),
        "add_option": MessageLookupByLibrary.simpleMessage("Добавить груз"),
        "add_photo": MessageLookupByLibrary.simpleMessage("Добавить фото"),
        "add_stor": MessageLookupByLibrary.simpleMessage("Добавить историю"),
        "address": MessageLookupByLibrary.simpleMessage("Адрес:"),
        "call": MessageLookupByLibrary.simpleMessage("Позвонить"),
        "cancel": MessageLookupByLibrary.simpleMessage("Отмена"),
        "chat": MessageLookupByLibrary.simpleMessage("Чат"),
        "city": MessageLookupByLibrary.simpleMessage("По городу"),
        "code_error": MessageLookupByLibrary.simpleMessage("Неверный код!"),
        "connect": MessageLookupByLibrary.simpleMessage("Связаться"),
        "create": MessageLookupByLibrary.simpleMessage("Создать"),
        "create_1": MessageLookupByLibrary.simpleMessage("Маршрут"),
        "create_2": MessageLookupByLibrary.simpleMessage("Откуда"),
        "create_3": MessageLookupByLibrary.simpleMessage("Куда"),
        "create_4": MessageLookupByLibrary.simpleMessage("Когда"),
        "create_shop":
            MessageLookupByLibrary.simpleMessage("Создать объявление"),
        "create_shop_house":
            MessageLookupByLibrary.simpleMessage("Введите номер дома"),
        "create_shop_house_":
            MessageLookupByLibrary.simpleMessage("Номер дома"),
        "create_shop_name":
            MessageLookupByLibrary.simpleMessage("Введите название"),
        "create_shop_name_": MessageLookupByLibrary.simpleMessage("Название"),
        "create_shop_street":
            MessageLookupByLibrary.simpleMessage("Введите улицу"),
        "create_shop_street_": MessageLookupByLibrary.simpleMessage("Улица"),
        "date": MessageLookupByLibrary.simpleMessage("Дата загрузки"),
        "date_": MessageLookupByLibrary.simpleMessage("Дата разгрузки"),
        "date_create": MessageLookupByLibrary.simpleMessage("Когда забрать"),
        "date_pick": MessageLookupByLibrary.simpleMessage("Выберите дату"),
        "desc": MessageLookupByLibrary.simpleMessage("Описание"),
        "doc": MessageLookupByLibrary.simpleMessage("Документы"),
        "dog": MessageLookupByLibrary.simpleMessage("Договорная"),
        "download_file": MessageLookupByLibrary.simpleMessage("Скачать файл"),
        "edit": MessageLookupByLibrary.simpleMessage("Изменить"),
        "edit_location":
            MessageLookupByLibrary.simpleMessage("Изменить местоположение"),
        "end": MessageLookupByLibrary.simpleMessage("Завершить"),
        "enter_code": MessageLookupByLibrary.simpleMessage("Введите код"),
        "enter_money":
            MessageLookupByLibrary.simpleMessage("Введите сумму зачисления"),
        "enter_new_password":
            MessageLookupByLibrary.simpleMessage("Введите новый пароль"),
        "error": MessageLookupByLibrary.simpleMessage("Ошибка"),
        "exit": MessageLookupByLibrary.simpleMessage("Выход"),
        "files": MessageLookupByLibrary.simpleMessage(
            "Например, фото груза. Форматы: GIF, JPEG, PNG, TXT, PDF, DOC и тд."),
        "files_photo": MessageLookupByLibrary.simpleMessage(
            "Фото. Форматы JPEG, PNG и тд."),
        "forgot_password":
            MessageLookupByLibrary.simpleMessage("Забыли пароль?"),
        "go_to_chat": MessageLookupByLibrary.simpleMessage("Перейти в чат"),
        "gos_number": MessageLookupByLibrary.simpleMessage("Госномер"),
        "gos_number_": MessageLookupByLibrary.simpleMessage("Введите госномер"),
        "help": MessageLookupByLibrary.simpleMessage("Помощь с приложением"),
        "help_1": MessageLookupByLibrary.simpleMessage("Удаление аккаунта"),
        "loading": MessageLookupByLibrary.simpleMessage("Загрузка..."),
        "min_sum": MessageLookupByLibrary.simpleMessage(
            "Минимальная сумма оплаты 1\$"),
        "name": MessageLookupByLibrary.simpleMessage("Имя"),
        "name_": MessageLookupByLibrary.simpleMessage("Введите имя"),
        "no_city": MessageLookupByLibrary.simpleMessage("Межгород"),
        "not_fount": MessageLookupByLibrary.simpleMessage("Не найдено"),
        "number_phone": MessageLookupByLibrary.simpleMessage("Номер телефона"),
        "number_phone_":
            MessageLookupByLibrary.simpleMessage("Введите номер телефона"),
        "ok": MessageLookupByLibrary.simpleMessage("Подтвердить"),
        "option1": MessageLookupByLibrary.simpleMessage("Межгород"),
        "option2": MessageLookupByLibrary.simpleMessage("По городу"),
        "page1": MessageLookupByLibrary.simpleMessage("Сварщики"),
        "page10": MessageLookupByLibrary.simpleMessage("Паркетчик"),
        "page11": MessageLookupByLibrary.simpleMessage("Электрики"),
        "page12": MessageLookupByLibrary.simpleMessage("Вентиляционщики"),
        "page13":
            MessageLookupByLibrary.simpleMessage("Вывоз строительного мусора"),
        "page14": MessageLookupByLibrary.simpleMessage("Токарь"),
        "page15": MessageLookupByLibrary.simpleMessage("Фрезеровщики"),
        "page16": MessageLookupByLibrary.simpleMessage("Маляр штукатур"),
        "page17": MessageLookupByLibrary.simpleMessage("Землекоп"),
        "page18": MessageLookupByLibrary.simpleMessage("Облицовщики"),
        "page19": MessageLookupByLibrary.simpleMessage("Столяры"),
        "page2": MessageLookupByLibrary.simpleMessage("Бетонщики"),
        "page20": MessageLookupByLibrary.simpleMessage("Геодезист"),
        "page21": MessageLookupByLibrary.simpleMessage("Плотники"),
        "page22": MessageLookupByLibrary.simpleMessage("Сантехники"),
        "page23": MessageLookupByLibrary.simpleMessage("Стропальщики"),
        "page24": MessageLookupByLibrary.simpleMessage("Крановщики"),
        "page25": MessageLookupByLibrary.simpleMessage("Каменщики"),
        "page26": MessageLookupByLibrary.simpleMessage("Печники"),
        "page27": MessageLookupByLibrary.simpleMessage("Монтажники"),
        "page28": MessageLookupByLibrary.simpleMessage("Кровельщики"),
        "page29": MessageLookupByLibrary.simpleMessage("Отделочники"),
        "page3": MessageLookupByLibrary.simpleMessage("Бульдозерист"),
        "page30": MessageLookupByLibrary.simpleMessage("Моторист"),
        "page31": MessageLookupByLibrary.simpleMessage("Другое"),
        "page4": MessageLookupByLibrary.simpleMessage("Мебельщики"),
        "page5": MessageLookupByLibrary.simpleMessage("Разнорабочий"),
        "page6": MessageLookupByLibrary.simpleMessage("Слесарь"),
        "page7": MessageLookupByLibrary.simpleMessage("Проектировщик"),
        "page8": MessageLookupByLibrary.simpleMessage("Газовщик"),
        "page9": MessageLookupByLibrary.simpleMessage("Стекольщик"),
        "password": MessageLookupByLibrary.simpleMessage("Пароль"),
        "password_": MessageLookupByLibrary.simpleMessage("Введите пароль"),
        "pay": MessageLookupByLibrary.simpleMessage("Оплата"),
        "payment":
            MessageLookupByLibrary.simpleMessage("Выберите способ оплаты"),
        "photo": MessageLookupByLibrary.simpleMessage("Фото"),
        "photo_": MessageLookupByLibrary.simpleMessage("Фото (Камера)"),
        "photo_gos":
            MessageLookupByLibrary.simpleMessage("Фото газели спереди"),
        "photo_gos_": MessageLookupByLibrary.simpleMessage(
            "Добавьте фото Газели спереди"),
        "photo_profile": MessageLookupByLibrary.simpleMessage("Фото профиля"),
        "photo_profile_":
            MessageLookupByLibrary.simpleMessage("Добавьте фото профиля"),
        "poput": MessageLookupByLibrary.simpleMessage("Попутчик"),
        "preload_page1": MessageLookupByLibrary.simpleMessage("Добавить груз"),
        "preload_page2":
            MessageLookupByLibrary.simpleMessage("Стать специалистом"),
        "preload_page3": MessageLookupByLibrary.simpleMessage("Найти груз"),
        "price": MessageLookupByLibrary.simpleMessage("Цена"),
        "price_": MessageLookupByLibrary.simpleMessage("Введите цену"),
        "profile_1": MessageLookupByLibrary.simpleMessage("Договор оферты"),
        "profile_2":
            MessageLookupByLibrary.simpleMessage("Политика конфиденциальности"),
        "reg": MessageLookupByLibrary.simpleMessage("Зарегистрироваться"),
        "register": MessageLookupByLibrary.simpleMessage("Регистрация"),
        "register_please": MessageLookupByLibrary.simpleMessage(
            "Зарегистрируйтесь или войдите чтобы посмотреть"),
        "save": MessageLookupByLibrary.simpleMessage("Сохранить груз"),
        "save_": MessageLookupByLibrary.simpleMessage("Сохранить"),
        "search": MessageLookupByLibrary.simpleMessage("Поиск"),
        "search_": MessageLookupByLibrary.simpleMessage("Поиск груза"),
        "select_city": MessageLookupByLibrary.simpleMessage("Выберите город"),
        "select_country":
            MessageLookupByLibrary.simpleMessage("Выберите страну"),
        "signin": MessageLookupByLibrary.simpleMessage("Вход"),
        "sum": MessageLookupByLibrary.simpleMessage("Сумма"),
        "surname": MessageLookupByLibrary.simpleMessage("Фамилия"),
        "surname_": MessageLookupByLibrary.simpleMessage("Введите фамилию"),
        "text": MessageLookupByLibrary.simpleMessage("Текст..."),
        "typing": MessageLookupByLibrary.simpleMessage("Написать"),
        "user": MessageLookupByLibrary.simpleMessage("Пользователь"),
        "user_name": MessageLookupByLibrary.simpleMessage("имя_пользователя"),
        "user_role_1": MessageLookupByLibrary.simpleMessage("Работодатель"),
        "user_role_2": MessageLookupByLibrary.simpleMessage("Специалист"),
        "video": MessageLookupByLibrary.simpleMessage("Видео"),
        "video_": MessageLookupByLibrary.simpleMessage("Видео (Камера)"),
        "warning_1":
            MessageLookupByLibrary.simpleMessage("Заполните все пустые поля"),
        "warning_2": MessageLookupByLibrary.simpleMessage(
            "Сначала введите номер телефона!"),
        "warning_3":
            MessageLookupByLibrary.simpleMessage("Выберите фотографию!")
      };
}
